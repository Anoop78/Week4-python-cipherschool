# built in errors 
# exception , how to handle them 
# raise your own errors, dubugging etc. etc.

# SYNTAX ERROR:
# def func:                  # parenthesis are missing
#     pass              


# name = "harshit"*
    
    
# IDENTATION ERROR


# def func():
    # print("hello/")
#   print("world")      


# NAME ERROR

# print(name)


# TYPE ERROR:

# print(5+"harshit")

# INDEX ERROR:

# l = [1,2,3]
# print(l[4])


# VALUE ERROR:
# s = "abc"
# print(int(s))

# ATTRIBUTE ERROR:
# l = [1,2,3]
# l.push("12")

# KEY ERROR:
d = {"name": "harshit"}
print(d['age'])